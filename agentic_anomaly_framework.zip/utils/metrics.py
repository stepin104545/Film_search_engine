# utils/metrics.py
import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score, precision_recall_curve

def auroc(y_true, y_score):
    return roc_auc_score(y_true, y_score) if len(np.unique(y_true))>1 else np.nan

def auprc(y_true, y_score):
    return average_precision_score(y_true, y_score) if len(np.unique(y_true))>1 else np.nan

def f1_at_optimal_threshold(y_true, y_score):
    p, r, t = precision_recall_curve(y_true, y_score)
    f1s = 2 * p * r / (p + r + 1e-12)
    idx = np.nanargmax(f1s)
    return f1s[idx], t[idx] if idx < len(t) else 0.5

def expected_cost(y_true, y_pred, fp_cost=1.0, fn_cost=10.0):
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    fp = ((y_pred==1) & (y_true==0)).sum()
    fn = ((y_pred==0) & (y_true==1)).sum()
    return fp_cost*fp + fn_cost*fn
