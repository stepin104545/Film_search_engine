# utils/data.py
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

def load_csv(path, features=None, label_col="label", target_col="target", standardize=True):
    df = pd.read_csv(path)
    if features is None:
        features = [c for c in df.columns if c not in [label_col, target_col]]
    X = df[features].astype(float).values
    y = df[label_col].values if label_col in df.columns else None
    t = df[target_col].values if target_col in df.columns else None
    scaler = None
    if standardize:
        scaler = StandardScaler()
        X = scaler.fit_transform(X)
    return X, y, t, features, scaler

def split_temporal(df, time_col, train_ratio=0.7, val_ratio=0.1):
    df = df.sort_values(time_col)
    n = len(df)
    train_end = int(n * train_ratio)
    val_end = int(n * (train_ratio + val_ratio))
    return df.iloc[:train_end], df.iloc[train_end:val_end], df.iloc[val_end:]
