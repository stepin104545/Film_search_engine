# agent/feature_proposals.py
import numpy as np
import pandas as pd

def add_poly2(df, feature_cols):
    out = df.copy()
    for c in feature_cols:
        out[f"{c}^2"] = out[c] ** 2
    return out

def add_quantile_bins(df, feature_cols, num_bins=10):
    out = df.copy()
    for c in feature_cols:
        try:
            out[f"{c}_bin"] = pd.qcut(out[c], q=num_bins, labels=False, duplicates='drop')
        except Exception:
            out[f"{c}_bin"] = pd.qcut(out[c].rank(method='first'), q=num_bins, labels=False)
    return out
