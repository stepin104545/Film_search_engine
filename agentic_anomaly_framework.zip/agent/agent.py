# agent/agent.py
import json, time, numpy as np
from sklearn.metrics import precision_recall_curve
from utils.metrics import auprc, expected_cost

class AgenticController:
    """
    Two variants:
      - mode='threshold': only threshold recalibration
      - mode='full': threshold + feature proposals + retraining triggers
    Logs reasoning to a JSONL file.
    """
    def __init__(self, cfg, log_path="logs/agent_trace.jsonl"):
        self.cfg = cfg
        self.mode = cfg['agent']['mode']
        self.log_path = log_path
        self.best_metric = -1.0
        self.metric_name = cfg['agent']['recalibration']['metric']

    def log(self, record):
        with open(self.log_path, "a") as f:
            f.write(json.dumps(record) + "\n")

    def choose_threshold(self, y_true, scores):
        # optimize threshold for chosen metric
        p, r, t = precision_recall_curve(y_true, scores)
        f1s = 2*p*r/(p+r+1e-12)
        idx = int(np.nanargmax(f1s))
        tau = t[idx] if idx < len(t) else 0.5
        metric = auprc(y_true, scores)
        self.log({"event":"threshold_recalibration", "tau": float(tau), "auprc": float(metric)})
        return tau, metric

    def should_retrain(self, current_metric):
        if self.best_metric < 0: 
            self.best_metric = current_metric
            return False
        drop = (self.best_metric - current_metric) / max(self.best_metric, 1e-6)
        trigger = drop >= self.cfg['agent']['retrain_trigger']['drop_threshold']
        self.log({"event":"retrain_check", "best": self.best_metric, "current": current_metric, "drop": drop, "trigger": trigger})
        if trigger:
            self.best_metric = current_metric  # reset after trigger
        else:
            self.best_metric = max(self.best_metric, current_metric)
        return trigger
