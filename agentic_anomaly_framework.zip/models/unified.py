# models/unified.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions.multivariate_normal import MultivariateNormal

class MLP(nn.Module):
    def __init__(self, in_dim, hidden, out_dim, dropout=0.0):
        super().__init__()
        layers = []
        d = in_dim
        for h in hidden:
            layers += [nn.Linear(d, h), nn.ReLU(), nn.Dropout(dropout)]
            d = h
        layers.append(nn.Linear(d, out_dim))
        self.net = nn.Sequential(*layers)
    def forward(self, x):
        return self.net(x)

class UnifiedAnomalyModel(nn.Module):
    """
    Encoder -> latent z
    GMM-like head with K clusters + anomaly component epsilon
    Regression heads G (inlier) and H (anomaly)
    """
    def __init__(self, input_dim, latent_dim=16, hidden=[128,64], K=5, epsilon=0.02, dropout=0.1):
        super().__init__()
        self.encoder = MLP(input_dim, hidden, latent_dim, dropout=dropout)
        self.K = K
        self.latent_dim = latent_dim
        self.epsilon = nn.Parameter(torch.tensor(epsilon))
        # Cluster params
        self.pi_logits = nn.Parameter(torch.zeros(K))
        self.mu = nn.Parameter(torch.randn(K, latent_dim) * 0.1)
        # Diagonal covariances for stability
        self.log_sigma = nn.Parameter(torch.zeros(K, latent_dim))
        # Regression heads
        self.reg_inlier = MLP(latent_dim, [64,32], 1, dropout=dropout)
        self.reg_outlier = MLP(latent_dim, [64,32], 1, dropout=dropout)

    def gmm_log_prob(self, z):
        # z: [B, D]
        B, D = z.shape
        pi = torch.softmax(self.pi_logits, dim=0)  # [K]
        comp = []
        for k in range(self.K):
            mean = self.mu[k]          # [D]
            var = torch.exp(2*self.log_sigma[k]) + 1e-6  # [D]
            log_det = torch.sum(torch.log(var))
            diff = z - mean
            maha = torch.sum(diff*diff/var, dim=1)
            log_prob = -0.5*(maha + log_det + D*torch.log(torch.tensor(2*3.14159265)))
            comp.append(log_prob + torch.log(pi[k]+1e-12))
        log_mix = torch.logsumexp(torch.stack(comp, dim=1), dim=1)  # [B]
        return log_mix

    def forward(self, x):
        z = self.encoder(x)  # [B, D]
        log_p_inlier = self.gmm_log_prob(z)  # [B]
        eps = torch.clamp(self.epsilon, 1e-4, 0.3)
        # Simple uniform component: constant density c dropped in ratios
        # Define total log-prob via log-sum-exp between inlier and anomaly:
        # p(z) = (1-eps)*p_inlier(z) + eps * U(z) ~ we absorb U into a constant.
        # We approximate with log-sum-exp of (log(1-eps)+log_p_inlier) and (log(eps)+c)
        c = -torch.ones_like(log_p_inlier) * 10.0  # proxy constant for U(z)
        log_pz = torch.logsumexp(torch.stack([torch.log(1-eps) + log_p_inlier,
                                              torch.log(eps) + c], dim=1), dim=1)
        # anomaly score s = -log( p_inlier / p_total )
        s = -(log_p_inlier - log_pz)
        # Regression heads
        y_in = self.reg_inlier(z).squeeze(-1)
        y_out = self.reg_outlier(z).squeeze(-1)
        return z, s, log_p_inlier, log_pz, y_in, y_out

def anomaly_repulsion(z, mu):
    # R(z): distance to nearest cluster center
    # z: [B, D], mu: [K, D]
    diff = z.unsqueeze(1) - mu.unsqueeze(0)  # [B,K,D]
    dist2 = torch.sum(diff*diff, dim=2)      # [B,K]
    return torch.min(dist2, dim=1).values
