# eval.py
import argparse, yaml, os, json
import numpy as np
import torch
from torch.utils.data import TensorDataset, DataLoader
from models.unified import UnifiedAnomalyModel
from utils.data import load_csv
from utils.metrics import auprc, auroc, f1_at_optimal_threshold, expected_cost

def load_model(cfg, path="model.pt"):
    ckpt = torch.load(path, map_location="cpu")
    model = UnifiedAnomalyModel(input_dim=cfg['model']['input_dim'],
                                latent_dim=cfg['model']['latent_dim'],
                                hidden=cfg['model']['hidden'],
                                K=cfg['model']['K'],
                                epsilon=cfg['model']['epsilon'],
                                dropout=cfg['model']['dropout'])
    model.load_state_dict(ckpt['model'])
    model.eval()
    return model

def main(cfg, mode):
    device = torch.device(cfg['device'] if torch.cuda.is_available() else 'cpu')
    Xte, yte, tte, feats, _ = load_csv(cfg['data']['test_csv'],
                                       cfg['data']['features'],
                                       cfg['data']['label_col'],
                                       cfg['data']['target_col'],
                                       cfg['data']['standardize'])
    model = load_model(cfg, "model.pt").to(device)
    Xte = torch.tensor(Xte, dtype=torch.float32).to(device)
    with torch.no_grad():
        _, s, _, _, _, _ = model(Xte)
    scores = s.cpu().numpy()
    y = yte if yte is not None else np.zeros_like(scores)
    auprc_v = auprc(y, scores); auroc_v = auroc(y, scores)
    f1, tau = f1_at_optimal_threshold(y, scores)
    y_hat = (scores >= tau).astype(int)
    cost = expected_cost(y, y_hat, **cfg['metrics']['cost'])
    out = {"auprc": float(auprc_v), "auroc": float(auroc_v), "f1": float(f1), "tau": float(tau), "cost": float(cost)}
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--mode", default="eval")
    args = ap.parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)
    main(cfg, args.mode)
