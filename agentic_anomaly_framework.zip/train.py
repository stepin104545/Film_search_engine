# train.py
import argparse, yaml, os, json
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import average_precision_score
from models.unified import UnifiedAnomalyModel, anomaly_repulsion
from utils.data import load_csv
from utils.metrics import auprc, auroc, f1_at_optimal_threshold

def set_seed(s):
    import random
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)

def make_loader(X, y, t, batch, device):
    X = torch.tensor(X, dtype=torch.float32)
    y = torch.tensor(y, dtype=torch.float32) if y is not None else torch.zeros(len(X))
    t = torch.tensor(t, dtype=torch.float32) if t is not None else torch.zeros(len(X))
    ds = TensorDataset(X, y, t)
    return DataLoader(ds, batch_size=batch, shuffle=True)

def train(cfg):
    device = torch.device(cfg['device'] if torch.cuda.is_available() else 'cpu')
    set_seed(cfg['seed'])
    Xtr, ytr, ttr, feats, _ = load_csv(cfg['data']['train_csv'],
                                       cfg['data']['features'],
                                       cfg['data']['label_col'],
                                       cfg['data']['target_col'],
                                       cfg['data']['standardize'])
    Xva, yva, tva, _, _ = load_csv(cfg['data']['val_csv'],
                                   feats, cfg['data']['label_col'],
                                   cfg['data']['target_col'],
                                   cfg['data']['standardize'])
    model = UnifiedAnomalyModel(input_dim=Xtr.shape[1],
                                latent_dim=cfg['model']['latent_dim'],
                                hidden=cfg['model']['hidden'],
                                K=cfg['model']['K'],
                                epsilon=cfg['model']['epsilon'],
                                dropout=cfg['model']['dropout']).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=cfg['opt']['lr'], weight_decay=cfg['opt']['weight_decay'])

    tr_loader = make_loader(Xtr, ytr, ttr, cfg['opt']['batch_size'], device)
    va_loader = make_loader(Xva, yva, tva, cfg['opt']['batch_size'], device)

    alpha = cfg['model']['alpha']; beta = cfg['model']['beta']
    bce = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(cfg['data']['imbalance_positive_weight']).to(device))

    best_va = -1; best_path = "model.pt"
    for epoch in range(cfg['opt']['epochs']):
        model.train()
        losses = []
        for xb, yb, tb in tr_loader:
            xb, yb, tb = xb.to(device), yb.to(device), tb.to(device)
            z, s, log_pin, log_pz, y_in, y_out = model(xb)
            # Anomaly indicator proxy: sigmoid(s - tau0). Here tau0=0 as proxy; supervised labels if available.
            # If labels exist, use them to supervise anomaly via BCE on s (after sigmoid).
            if (yb is not None) and (cfg['task']['has_labels']):
                p_anom = torch.sigmoid(s)
                loss_cls = bce(p_anom, yb)
            else:
                loss_cls = torch.tensor(0.0, device=device)

            # Likelihood (maximize log_pz) -> minimize negative
            nll = - torch.mean(log_pz)

            # Repulsion penalty for anomalies (use s as soft weight)
            rep = anomaly_repulsion(z, model.mu)
            rep_weight = torch.sigmoid(s)  # higher for anomalies
            rep_loss = torch.mean(rep_weight * rep)

            # Regression (if target exists)
            if cfg['task']['has_regression_target'] and tb is not None:
                # choose y_in for inliers, y_out for anomalies using soft gates
                gate = torch.sigmoid(-s) # inlier prob
                y_hat = gate * y_in + (1-gate) * y_out
                reg_loss = torch.mean((y_hat - tb)**2)
            else:
                reg_loss = torch.tensor(0.0, device=device)

            loss = nll + alpha * rep_loss + beta * reg_loss + loss_cls
            opt.zero_grad(); loss.backward(); opt.step()
            losses.append(loss.item())

        # Validation
        model.eval()
        with torch.no_grad():
            all_y, all_s = [], []
            for xb, yb, tb in va_loader:
                xb, yb = xb.to(device), yb.to(device)
                _, s, _, _, _, _ = model(xb)
                all_s.append(s.cpu().numpy())
                all_y.append(yb.cpu().numpy())
            all_s = np.concatenate(all_s); all_y = np.concatenate(all_y)
            cur_auprc = auprc(all_y, all_s)
        print(f"Epoch {epoch+1}: loss={np.mean(losses):.4f}, val AUPRC={cur_auprc:.4f}")
        if cur_auprc > best_va:
            best_va = cur_auprc
            torch.save({"model": model.state_dict(), "feats": feats}, os.path.join("model.pt"))
    print(f"Best val AUPRC: {best_va:.4f}. Saved to model.pt")

if __name__ == "__main__":
    import argparse, yaml
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)
    train(cfg)
