# run_agent.py
import argparse, yaml, json, os
import numpy as np
import pandas as pd
import torch
from models.unified import UnifiedAnomalyModel
from utils.data import load_csv
from utils.metrics import auprc, auroc, f1_at_optimal_threshold, expected_cost
from agent.agent import AgenticController
from agent.feature_proposals import add_poly2, add_quantile_bins

def load_model(cfg, path="model.pt"):
    ckpt = torch.load(path, map_location="cpu")
    model = UnifiedAnomalyModel(input_dim=cfg['model']['input_dim'],
                                latent_dim=cfg['model']['latent_dim'],
                                hidden=cfg['model']['hidden'],
                                K=cfg['model']['K'],
                                epsilon=cfg['model']['epsilon'],
                                dropout=cfg['model']['dropout'])
    model.load_state_dict(ckpt['model'])
    model.eval()
    return model

def score_model(model, X, device):
    with torch.no_grad():
        Xt = torch.tensor(X, dtype=torch.float32).to(device)
        _, s, _, _, _, _ = model(Xt)
    return s.cpu().numpy()

def main(cfg):
    device = torch.device(cfg['device'] if torch.cuda.is_available() else 'cpu')
    agent = AgenticController(cfg)
    # Load validation (as recent window)
    Xva, yva, tva, feats, _ = load_csv(cfg['data']['val_csv'],
                                       cfg['data']['features'],
                                       cfg['data']['label_col'],
                                       cfg['data']['target_col'],
                                       cfg['data']['standardize'])
    model = load_model(cfg, "model.pt").to(device)
    scores = score_model(model, Xva, device)
    tau, metric = agent.choose_threshold(yva, scores)

    # Optionally propose features (full mode) -> This is a placeholder; real impl should re-train with new features
    if cfg['agent']['mode'] == "full" and cfg['agent']['feature_proposals']['enable_poly2']:
        agent.log({"event":"feature_proposal", "type":"poly2"})
    if cfg['agent']['mode'] == "full" and cfg['agent']['feature_proposals']['enable_quantile_bins']:
        agent.log({"event":"feature_proposal", "type":"quantile_bins", "num_bins": cfg['agent']['feature_proposals']['num_bins']})

    # Retraining decision
    retrain = agent.should_retrain(metric)
    print(json.dumps({"tau": float(tau), "metric": float(metric), "retrain": retrain}, indent=2))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)
    main(cfg)
