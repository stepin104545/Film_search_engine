# Agentic-Augmented Unified Framework for Anomaly Detection & Regression

This repo is a **reference implementation** of the framework discussed in your paper:
- Unified probabilistic clustering-based anomaly model with learned latent representation
- Joint regression heads for inliers vs anomalies
- Agentic module for threshold recalibration, feature proposals, and retraining triggers

## Quick Start (Tabular CSV)
1) Put your CSV in `data/` with columns:
   - Features: `f1 ... fM`
   - Binary label: `label` (1 = anomaly, 0 = normal). If unlabeled, set all 0 and use unsupervised only.
   - Optional regression target: `target` (float).
2) Update `configs/tabular.yaml` with paths & hyperparams.
3) Train unified model:
```bash
python train.py --config configs/tabular.yaml
```
4) Evaluate + run agent on a drifted split:
```bash
python eval.py --config configs/tabular.yaml --mode drift_eval
```
5) Run full agent loop (recalibrate threshold, propose features, trigger retraining):
```bash
python run_agent.py --config configs/tabular.yaml
```

## Notes
- Code uses PyTorch for the encoder and regression heads, and a differentiable mixture head for clustering.
- The **agent** logs its reasoning to `logs/agent_trace.jsonl`.
- Feature proposals are safe defaults (polynomial degree-2 and quantile binning). Extend in `agent/feature_proposals.py`.
- Replace dataset loader with your own (e.g., IEEE-CIS format) in `utils/data.py`.
